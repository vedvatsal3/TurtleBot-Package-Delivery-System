#!/usr/bin/env bash
set -u  # (avoid set -e here; if one tab fails it can abort the script)

gnome-terminal \
  --tab --title="delivery-server"  -e "bash -lc 'ros2 run delivery_interface_cpp delivery_server;  exec bash'" \
  --tab --title="monitor-client"   -e "bash -lc 'ros2 run delivery_interface_cpp monitor_client;   exec bash'" \
  --tab --title="sender-client"    -e "bash -lc 'ros2 run delivery_interface_cpp sender_client;    exec bash'" \
  --tab --title="receiver-client"  -e "bash -lc 'ros2 run delivery_interface_cpp receiver_client;  exec bash'"
