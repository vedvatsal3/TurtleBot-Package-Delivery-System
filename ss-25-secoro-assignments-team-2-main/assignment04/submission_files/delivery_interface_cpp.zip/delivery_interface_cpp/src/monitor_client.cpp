#include "rclcpp/rclcpp.hpp"              
#include "std_msgs/msg/string.hpp"        
 // make robot availeable ros2 topic pub /monitor/available std_msgs/String "data: 'george'"
class MonitorClient : public rclcpp::Node {
public:
  MonitorClient()
  : rclcpp::Node("monitor_client") 
  {
    
    sub_ = this->create_subscription<std_msgs::msg::String>(
      "/monitor/events",                     
      10,                                    
      [this](std_msgs::msg::String::SharedPtr msg) { 
        
        RCLCPP_WARN(this->get_logger(), "[MONITOR] %s", msg->data.c_str());
      }
    );

    RCLCPP_INFO(this->get_logger(), "MonitorClient läuft. Warte auf Ereignisse unter /monitor/events ...");
  }

private:
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr sub_; 
};

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);                         
  rclcpp::spin(std::make_shared<MonitorClient>());  
  rclcpp::shutdown();                               
  return 0;
}
