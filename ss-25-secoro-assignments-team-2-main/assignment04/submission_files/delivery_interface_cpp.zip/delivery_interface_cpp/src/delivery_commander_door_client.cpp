#include "rclcpp/rclcpp.hpp"
#include "nav2_msgs/action/navigate_to_pose.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "tf2/LinearMath/Quaternion.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.hpp"

#include <memory>
#include <chrono>
#include <iostream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <algorithm>

using NavigateToPose = nav2_msgs::action::NavigateToPose;
using GoalHandleNavigate = rclcpp_action::ClientGoalHandle<NavigateToPose>;

struct Waypoint { double x; double y; double yaw; };

const std::unordered_map<std::string, Waypoint> ROOM_LOCATIONS = {
  {"room_251", {-4.5, 1.7, 0.0}},
  {"room_252", {1.3, 1.7, 0.0}},
  {"room_253", {4.57, 1.7, 0.0}},
  {"room_254", {4.57, -1.7, 0.0}},
  {"room_255", {1.3, -1.7, 0.0}},
  {"room_256", {-1.3, -1.7, 0.0}},
  {"room_257", {-4.5, -1.7, 0.0}},
  {"room_test", {-0.5, -0.5, 0.0}},
  {"dock1", {-2.25, 2.4, 0.0}},
  {"dock2", {-2.55, 2.2, 0.0}},
};

std::unordered_set<std::string> BUSY_ROBOTS;
const std::vector<std::string> AVAILABLE_ROBOTS = {"george", "fred", "turtlebot4"};

class DeliveryCommander : public rclcpp::Node {
public:
  DeliveryCommander() : Node("delivery_commander_cpp") {
    std::vector<std::string> available;
    for (const auto &r : AVAILABLE_ROBOTS) {
      if (BUSY_ROBOTS.find(r) == BUSY_ROBOTS.end()) available.push_back(r);
    }
    if (available.empty()) {
      RCLCPP_ERROR(get_logger(), "No available robots.");
      rclcpp::shutdown();
      return;
    }

    std::cout << "Available robots: ";
    for (const auto &r : available) std::cout << r << " ";
    std::cout << "\nSelect namespace: ";
    std::getline(std::cin, namespace_);
    if (std::find(available.begin(), available.end(), namespace_) == available.end()) {
      RCLCPP_ERROR(get_logger(), "Invalid selection.");
      rclcpp::shutdown();
      return;
    }
    BUSY_ROBOTS.insert(namespace_);

    std::string action_name = "/" + namespace_ + "/navigate_to_pose";
    nav_client_ = rclcpp_action::create_client<NavigateToPose>(this, action_name);

    start_delivery_cycle();
  }

private:
  std::string namespace_;
  rclcpp_action::Client<NavigateToPose>::SharedPtr nav_client_;
  std::string pickup_room_;
  std::string state_;
  Waypoint current_target_;

  bool load_room_waypoint(const std::string &room) {
    auto it = ROOM_LOCATIONS.find(room);
    if (it == ROOM_LOCATIONS.end()) return false;
    current_target_ = it->second;
    return true;
  }

  void start_delivery_cycle() {
    std::cout << "Available pickup rooms:\n";
    for (const auto &p : ROOM_LOCATIONS) {
      if (p.first.rfind("room_", 0) == 0)
        std::cout << "  " << p.first << "\n";
    }
    std::cout << "Enter pickup room: ";
    std::getline(std::cin, pickup_room_);
    if (!load_room_waypoint(pickup_room_)) {
      RCLCPP_ERROR(get_logger(), "Invalid pickup room.");
      shutdown_or_restart();
      return;
    }
    state_ = "pickup";
    send_goal(current_target_);
  }

  void send_goal(const Waypoint &wp) {
    if (!nav_client_->wait_for_action_server(std::chrono::seconds(5))) {
      RCLCPP_ERROR(get_logger(), "NavigateToPose action server not available.");
      return;
    }

    auto goal_msg = NavigateToPose::Goal();

    geometry_msgs::msg::PoseStamped pose;
    pose.header.frame_id = "map";
    pose.header.stamp = this->get_clock()->now();
    pose.pose.position.x = wp.x;
    pose.pose.position.y = wp.y;

    tf2::Quaternion q;
    q.setRPY(0, 0, wp.yaw);
    pose.pose.orientation = tf2::toMsg(q);

    goal_msg.pose = pose;

    auto options = rclcpp_action::Client<NavigateToPose>::SendGoalOptions();
    options.feedback_callback = 
      [this](GoalHandleNavigate::SharedPtr, const std::shared_ptr<const NavigateToPose::Feedback> feedback) {
        // Could add near-goal detection here if desired.
      };
    options.goal_response_callback = 
      [this](std::shared_ptr<GoalHandleNavigate> goal_handle) {
        if (!goal_handle) {
          RCLCPP_ERROR(this->get_logger(), "Goal rejected.");
          return;
        }
        RCLCPP_INFO(this->get_logger(), "Goal accepted.");
      };
    options.result_callback = 
      [this](const GoalHandleNavigate::WrappedResult & result) {
        if (result.code == rclcpp_action::ResultCode::SUCCEEDED) {
          RCLCPP_INFO(this->get_logger(), "Arrived at destination.");
        } else {
          RCLCPP_WARN(this->get_logger(), "Navigation failed or aborted.");
        }
        continue_flow();
      };

    nav_client_->async_send_goal(goal_msg, options);
  }

  void continue_flow() {
    if (state_ == "pickup") {
      std::cout << "Sender: Confirm package loaded? [y]: ";
      std::string resp;
      std::getline(std::cin, resp);
      if (resp == "y") {
        state_ = "deliver";
        std::cout << "Enter delivery room: ";
        std::string dest;
        std::getline(std::cin, dest);
        if (load_room_waypoint(dest)) {
          send_goal(current_target_);
        } else {
          RCLCPP_ERROR(get_logger(), "Invalid delivery room.");
        }
      } else {
        state_ = "dock";
        load_room_waypoint("dock1");
        send_goal(current_target_);
      }
    } else if (state_ == "deliver") {
      std::cout << "Receiver: Confirm delivery? [y]: ";
      std::string resp;
      std::getline(std::cin, resp);
      if (resp == "y") {
        state_ = "dock";
        load_room_waypoint("dock1");
        send_goal(current_target_);
      } else {
        state_ = "return_to_sender";
        load_room_waypoint(pickup_room_);
        send_goal(current_target_);
      }
    } else if (state_ == "return_to_sender") {
      std::cout << "Sender: Confirm return? [y]: ";
      std::string resp;
      std::getline(std::cin, resp);
      if (resp == "y") {
        BUSY_ROBOTS.erase(namespace_);
        shutdown_or_restart();
      } else {
        state_ = "to_monitor";
        load_room_waypoint("room_251");
        send_goal(current_target_);
      }
    } else {
      RCLCPP_INFO(get_logger(), "Cycle complete. Robot free.");
      BUSY_ROBOTS.erase(namespace_);
      shutdown_or_restart();
    }
  }

  void shutdown_or_restart() {
    std::cout << "Do you want another delivery? [y/n]: ";
    std::string again;
    std::getline(std::cin, again);
    if (again == "y") {
      start_delivery_cycle();
    } else {
      rclcpp::shutdown();
    }
  }
};

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  auto node = std::make_shared<DeliveryCommander>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
