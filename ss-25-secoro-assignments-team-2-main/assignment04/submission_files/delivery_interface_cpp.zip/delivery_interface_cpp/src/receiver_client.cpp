#include <chrono>
#include <future>
#include <iostream>
#include <memory>
#include <optional>
#include <string>
#include <unordered_map>

#include "rclcpp/rclcpp.hpp"
#include "delivery_interface_cpp/srv/receiver_select_room.hpp"
#include "delivery_interface_cpp/srv/receiver_confirm.hpp"

using namespace std::chrono_literals;

struct Waypoint { double x; double y; double yaw; };

// Local room list for the UI (server still validates)
static const std::unordered_map<std::string, Waypoint> ROOM_LOCATIONS = {
  {"room_251", {-4.5,  1.7,  0.0}},
  {"room_252", { 1.3,  1.7,  0.0}},
  {"room_253", { 4.57, 1.7,  0.0}},
  {"room_254", { 4.57,-1.7,  0.0}},
  {"room_255", { 1.3, -1.7,  0.0}},
  {"room_256", {-1.3, -1.7,  0.0}},
  {"room_257", {-4.5, -1.7,  0.0}},
};

static std::optional<std::string> timed_prompt(const std::string &prompt, std::chrono::milliseconds timeout)
{
  std::cout << prompt << std::flush;
  auto fut = std::async(std::launch::async, [](){
    std::string s;
    std::getline(std::cin, s);
    return s;
  });
  if (fut.wait_for(timeout) == std::future_status::ready) {
    return fut.get();
  } else {
    std::cout << "\n[timeout]\n";
    return std::nullopt;
  }
}

class ReceiverClient : public rclcpp::Node {
public:
  ReceiverClient()
  : Node("receiver_client")
  {
    // /receiver/select_room
    select_room_srv_ = this->create_service<delivery_interface_cpp::srv::ReceiverSelectRoom>(
      "/receiver/select_room",
      std::bind(&ReceiverClient::on_select_room, this, std::placeholders::_1, std::placeholders::_2));

    // /receiver/confirm
    confirm_srv_ = this->create_service<delivery_interface_cpp::srv::ReceiverConfirm>(
      "/receiver/confirm",
      std::bind(&ReceiverClient::on_confirm, this, std::placeholders::_1, std::placeholders::_2));

    RCLCPP_INFO(this->get_logger(), "ReceiverClient ready. Keep this terminal open to select room & confirm pickup.");
  }

private:
  rclcpp::Service<delivery_interface_cpp::srv::ReceiverSelectRoom>::SharedPtr select_room_srv_;
  rclcpp::Service<delivery_interface_cpp::srv::ReceiverConfirm>::SharedPtr confirm_srv_;

  void on_select_room(
    const std::shared_ptr<delivery_interface_cpp::srv::ReceiverSelectRoom::Request> req,
    std::shared_ptr<delivery_interface_cpp::srv::ReceiverSelectRoom::Response> resp)
  {
    // Show rooms to make it easy for the user
    std::cout << "Available delivery rooms:\n";
    for (const auto &p : ROOM_LOCATIONS) {
      if (p.first.rfind("room_", 0) == 0) std::cout << "  " << p.first << "\n";
    }

    auto ans = timed_prompt(req->prompt, 12s); // server waits ~12s
    if (ans && !ans->empty()) {
      resp->room = *ans;
      resp->provided = true;
      std::cout << "room provided: " << resp->room << "\n";
    } else {
      resp->room = "";
      resp->provided = false;
      std::cout << "no room provided (timeout)\n";
    }
  }

  void on_confirm(
    const std::shared_ptr<delivery_interface_cpp::srv::ReceiverConfirm::Request> req,
    std::shared_ptr<delivery_interface_cpp::srv::ReceiverConfirm::Response> resp)
  {
    auto ans = timed_prompt(req->message, 6s);
    if (ans && !ans->empty() && (ans->at(0) == 'y' || ans->at(0) == 'Y')) {
      resp->confirmed = true;
      std::cout << "[receiver] ✔ confirmed\n";
    } else {
      resp->confirmed = false;
      std::cout << "[receiver] ✖ not confirmed (timeout or not 'y')\n";
    }
  }
};

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  auto node = std::make_shared<ReceiverClient>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
