#include <chrono>
#include <future>
#include <iostream>
#include <memory>
#include <optional>
#include <string>
#include <unordered_map>
#include <atomic>
#include "std_msgs/msg/string.hpp"
#include "rclcpp/rclcpp.hpp"
#include "delivery_interface_cpp/srv/delivery_command.hpp"
#include "delivery_interface_cpp/srv/sender_confirm.hpp"
#include <thread>
#include <functional>


using namespace std::chrono_literals;

struct Waypoint { double x; double y; double yaw; };

// Local room list just to help the user pick valid names.
// (Server also validates; keeping this here is for UX parity with your Python tool.)
static const std::unordered_map<std::string, Waypoint> ROOM_LOCATIONS = {
  {"room_251", {-4.5,  1.7,  0.0}},
  {"room_252", { 1.3,  1.7,  0.0}},
  {"room_253", { 4.57, 1.7,  0.0}},
  {"room_254", { 4.57,-1.7,  0.0}},
  {"room_255", { 1.3, -1.7,  0.0}},
  {"room_256", {-1.3, -1.7,  0.0}},
  {"room_257", {-4.5, -1.7,  0.0}},
};

static std::optional<std::string> timed_prompt(const std::string &prompt, std::chrono::milliseconds timeout)
{
  std::cout << prompt << std::flush;
  auto fut = std::async(std::launch::async, [](){
    std::string s;
    std::getline(std::cin, s);
    return s;
  });
  if (fut.wait_for(timeout) == std::future_status::ready) {
    return fut.get();
  } else {
    std::cout << "\n[timeout]\n";
    return std::nullopt;
  }
}

class SenderClient : public rclcpp::Node {
public:
  SenderClient()
  : Node("sender_client")
  {
    // Service server: /sender/confirm  (server calls us)
    sender_confirm_srv_ = this->create_service<delivery_interface_cpp::srv::SenderConfirm>(
      "/sender/confirm",
      std::bind(&SenderClient::on_sender_confirm, this, std::placeholders::_1, std::placeholders::_2));

    // Service client: /delivery_command  (we call server)
    delivery_client_ = this->create_client<delivery_interface_cpp::srv::DeliveryCommand>("/delivery_command");
    
    // Start interactive loop in a background thread so we can still serve callbacks
    input_thread_ = std::thread([this](){ this->interactive_once(); });

    RCLCPP_INFO(this->get_logger(), "SenderClient ready. Use this terminal to start deliveries and confirm load/return.");

    
  }

  ~SenderClient() override {
    if (input_thread_.joinable()) input_thread_.join();
  }

private:
  rclcpp::Service<delivery_interface_cpp::srv::SenderConfirm>::SharedPtr sender_confirm_srv_;
  rclcpp::Client<delivery_interface_cpp::srv::DeliveryCommand>::SharedPtr delivery_client_;
  std::thread input_thread_;
  std::atomic<bool> active_delivery_{false};
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr monitor_sub_;


  void on_sender_confirm(
    const std::shared_ptr<delivery_interface_cpp::srv::SenderConfirm::Request> req,
    std::shared_ptr<delivery_interface_cpp::srv::SenderConfirm::Response> resp)
  {
    // Mirror Python's behavior: prompt with a short timeout
    auto ans = timed_prompt(req->message, 600s);
    if (ans && !ans->empty() && (ans->at(0) == 'y' || ans->at(0) == 'Y')) {
      resp->confirmed = true;
      std::cout << "[sender] ✔ confirmed\n";
    } else {
      resp->confirmed = false;
      std::cout << "[sender] ✖ not confirmed (timeout or not 'y')\n";
    }
  }

  void interactive_once() {
    // Nur ein Durchlauf
    // Rooms anzeigen ...
    std::cout << "Available pickup rooms:\n";
    for (const auto &p : ROOM_LOCATIONS) {
      if (p.first.rfind("room_", 0) == 0) std::cout << "  " << p.first << "\n";
    }

    // RICHTIG: pickup zuerst, dann delivery
    std::string pickup, delivery;
    std::cout << "Enter pickup room (Your room): " << std::flush;
    std::getline(std::cin, pickup);
    std::cout << "Enter delivery room (The receiver room): " << std::flush;
    std::getline(std::cin, delivery);

    if (pickup.empty() || delivery.empty()) {
      std::cout << "Pickup and delivery must be non-empty.\n";
      return;
    }
    if (pickup == delivery) {
      std::cout << "Pickup and delivery cannot be the same.\n";
      return;
    }
    if (ROOM_LOCATIONS.find(pickup) == ROOM_LOCATIONS.end()) {
      std::cout << "Warning: unknown pickup room.\n";
    }
    if (!delivery_client_->wait_for_service(10s)) {
      std::cout << "Error: /delivery_command not available.\n";
      return;
    }

    auto req = std::make_shared<delivery_interface_cpp::srv::DeliveryCommand::Request>();
    req->pickup_room = pickup;
    req->delivery_room = delivery;

    auto fut = delivery_client_->async_send_request(req);
    if (fut.wait_for(5s) != std::future_status::ready) {
      std::cout << "Error: no response from delivery server.\n";
      return;
    }
    auto resp = fut.get();
    if (resp->accepted) {
      std::cout << "Delivery accepted. Assigned robot: " << resp->assigned_robot << "\n";
    } else {
      std::cout << "Delivery rejected (no robot or invalid room).\n";
    }
  }
};

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  auto node = std::make_shared<SenderClient>();
  // Multi-threaded spinner so callbacks keep working while input thread runs
  rclcpp::executors::MultiThreadedExecutor exec;
  exec.add_node(node);
  exec.spin();
  rclcpp::shutdown();
  return 0;
}

