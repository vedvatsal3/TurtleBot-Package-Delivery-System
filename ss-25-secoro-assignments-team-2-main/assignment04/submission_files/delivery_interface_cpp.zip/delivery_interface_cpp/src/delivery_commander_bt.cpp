#include <behaviortree_cpp_v3/bt_factory.h>
#include <behaviortree_cpp_v3/action_node.h>
#include <behaviortree_cpp_v3/condition_node.h>

#include <rclcpp/rclcpp.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include <nav2_msgs/action/navigate_to_pose.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>

#include <iostream>
#include <unordered_map>
#include <string>
#include <memory>
#include <thread>

using NavigateToPose = nav2_msgs::action::NavigateToPose;
using GoalHandleNavigate = rclcpp_action::ClientGoalHandle<NavigateToPose>;

struct Waypoint { double x; double y; double yaw; };

const std::unordered_map<std::string, Waypoint> ROOM_LOCATIONS = {
  {"room_251", {-4.5, 1.7, 0.0}},
  {"room_252", {1.3, 1.7, 0.0}},
  {"room_253", {4.57, 1.7, 0.0}},
  {"room_254", {4.57, -1.7, 0.0}},
  {"room_255", {1.3, -1.7, 0.0}},
  {"room_256", {-1.3, -1.7, 0.0}},
  {"room_257", {-4.5, -1.7, 0.0}},
  {"dock1", {-2.25, 2.4, 0.0}}
};

rclcpp::Node::SharedPtr ros_node;

// -------------------- BT Nodes --------------------

// Select robot namespace
class SelectRobot : public BT::SyncActionNode {
public:
  SelectRobot(const std::string& name, const BT::NodeConfiguration& config)
    : BT::SyncActionNode(name, config) {}
  static BT::PortsList providedPorts() { return {BT::OutputPort<std::string>("selected_robot")}; }
  BT::NodeStatus tick() override {
    std::vector<std::string> available = {"george", "fred", "turtlebot4"};
    std::cout << "Available robots: ";
    for (auto& r : available) std::cout << r << " ";
    std::cout << "\nSelect namespace: ";
    std::string ns; std::getline(std::cin, ns);
    setOutput("selected_robot", ns);
    return BT::NodeStatus::SUCCESS;
  }
};

// Ask pickup room
class AskPickupRoom : public BT::SyncActionNode {
public:
  AskPickupRoom(const std::string& name, const BT::NodeConfiguration& config)
    : BT::SyncActionNode(name, config) {}
  static BT::PortsList providedPorts() { return {BT::OutputPort<std::string>("pickup_room")}; }
  BT::NodeStatus tick() override {
    std::cout << "Enter pickup room: ";
    std::string room; std::getline(std::cin, room);
    setOutput("pickup_room", room);
    return BT::NodeStatus::SUCCESS;
  }
};

// Ask delivery room
class AskDeliveryRoom : public BT::SyncActionNode {
public:
  AskDeliveryRoom(const std::string& name, const BT::NodeConfiguration& config)
    : BT::SyncActionNode(name, config) {}
  static BT::PortsList providedPorts() { return {BT::OutputPort<std::string>("delivery_room")}; }
  BT::NodeStatus tick() override {
    std::cout << "Enter delivery room: ";
    std::string room; std::getline(std::cin, room);
    setOutput("delivery_room", room);
    return BT::NodeStatus::SUCCESS;
  }
};

// Ask confirmation (y/n)
class AskConfirmation : public BT::SyncActionNode {
public:
  AskConfirmation(const std::string& name, const BT::NodeConfiguration& config)
    : BT::SyncActionNode(name, config) {}
  static BT::PortsList providedPorts() {
    return {
      BT::InputPort<std::string>("prompt"),
      BT::OutputPort<bool>("confirmed")
    };
  }
  BT::NodeStatus tick() override {
    auto prompt = getInput<std::string>("prompt").value();
    std::cout << prompt << " [y/n]: ";
    std::string ans; std::getline(std::cin, ans);
    bool ok = (!ans.empty() && (ans[0] == 'y' || ans[0] == 'Y'));
    setOutput("confirmed", ok);
    return BT::NodeStatus::SUCCESS;
  }
};

// Navigate to waypoint
class NavigateToWaypoint : public BT::SyncActionNode {
public:
  NavigateToWaypoint(const std::string& name, const BT::NodeConfiguration& config)
    : BT::SyncActionNode(name, config) {}
  static BT::PortsList providedPorts() { return {BT::InputPort<std::string>("waypoint")}; }
  BT::NodeStatus tick() override {
    std::string wp_name;
    if (!getInput("waypoint", wp_name)) return BT::NodeStatus::FAILURE;
    auto it = ROOM_LOCATIONS.find(wp_name);
    if (it == ROOM_LOCATIONS.end()) {
      std::cerr << "Unknown waypoint: " << wp_name << std::endl;
      return BT::NodeStatus::FAILURE;
    }
    auto wp = it->second;

    auto client = rclcpp_action::create_client<NavigateToPose>(ros_node, "/turtlebot4/navigate_to_pose");
    if (!client->wait_for_action_server(std::chrono::seconds(5))) {
      std::cerr << "NavigateToPose server not available\n";
      return BT::NodeStatus::FAILURE;
    }

    NavigateToPose::Goal goal;
    goal.pose.header.frame_id = "map";
    goal.pose.header.stamp = ros_node->now();
    goal.pose.pose.position.x = wp.x;
    goal.pose.pose.position.y = wp.y;
    tf2::Quaternion q; q.setRPY(0, 0, wp.yaw);
    goal.pose.pose.orientation = tf2::toMsg(q);

    auto send_goal_future = client->async_send_goal(goal);
    rclcpp::spin_until_future_complete(ros_node, send_goal_future);
    return BT::NodeStatus::SUCCESS;
  }
};

// Restart or shutdown
class AskRestart : public BT::SyncActionNode {
public:
  AskRestart(const std::string& name, const BT::NodeConfiguration& config)
    : BT::SyncActionNode(name, config) {}
  static BT::PortsList providedPorts() { return {BT::OutputPort<bool>("restart")}; }
  BT::NodeStatus tick() override {
    std::cout << "Do you want another delivery? [y/n]: ";
    std::string ans; std::getline(std::cin, ans);
    bool again = (!ans.empty() && (ans[0] == 'y' || ans[0] == 'Y'));
    setOutput("restart", again);
    return BT::NodeStatus::SUCCESS;
  }
};

// Generic bool condition
class BoolCondition : public BT::ConditionNode {
public:
  BoolCondition(const std::string& name, const BT::NodeConfiguration& config)
      : BT::ConditionNode(name, config) {}
  static BT::PortsList providedPorts() { return {BT::InputPort<bool>("value")}; }
  BT::NodeStatus tick() override {
    auto val = getInput<bool>("value").value_or(false);
    return val ? BT::NodeStatus::SUCCESS : BT::NodeStatus::FAILURE;
  }
};

// -------------------- MAIN --------------------
int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  ros_node = rclcpp::Node::make_shared("delivery_commander_bt");

  BT::BehaviorTreeFactory factory;
  factory.registerNodeType<SelectRobot>("SelectRobot");
  factory.registerNodeType<AskPickupRoom>("AskPickupRoom");
  factory.registerNodeType<AskDeliveryRoom>("AskDeliveryRoom");
  factory.registerNodeType<AskConfirmation>("AskConfirmation");
  factory.registerNodeType<NavigateToWaypoint>("NavigateToWaypoint");
  factory.registerNodeType<AskRestart>("AskRestart");
  factory.registerNodeType<BoolCondition>("BoolCondition");

  static const char* xml_text = R"(
<root main_tree_to_execute="MainTree">
  <BehaviorTree ID="MainTree">
    <Sequence name="RootSequence">
      <SelectRobot selected_robot="robot"/>
      <AskPickupRoom pickup_room="pickup"/>
      <NavigateToWaypoint waypoint="{pickup}"/>
      <AskConfirmation prompt="Sender: confirm package loaded?" confirmed="load_ok"/>
      <Fallback>
        <Sequence>
          <BoolCondition value="{load_ok}"/>
          <AskDeliveryRoom delivery_room="target"/>
          <NavigateToWaypoint waypoint="{target}"/>
          <AskConfirmation prompt="Receiver: confirm delivery?" confirmed="deliver_ok"/>
          <Fallback>
            <Sequence>
              <BoolCondition value="{deliver_ok}"/>
              <NavigateToWaypoint waypoint="dock1"/>
            </Sequence>
            <Sequence>
              <NavigateToWaypoint waypoint="{pickup}"/>
              <AskConfirmation prompt="Sender: confirm return?" confirmed="return_ok"/>
              <Fallback>
                <BoolCondition value="{return_ok}"/>
                <NavigateToWaypoint waypoint="room_251"/>
              </Fallback>
            </Sequence>
          </Fallback>
        </Sequence>
        <NavigateToWaypoint waypoint="dock1"/>
      </Fallback>
      <AskRestart restart="again"/>
    </Sequence>
  </BehaviorTree>
</root>
  )";

  auto tree = factory.createTreeFromText(xml_text);

  BT::NodeStatus status = BT::NodeStatus::RUNNING;
  while (rclcpp::ok() && status == BT::NodeStatus::RUNNING) {
    status = tree.tickRoot();
    rclcpp::spin_some(ros_node);
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
  }

  rclcpp::shutdown();
  return 0;
}


































