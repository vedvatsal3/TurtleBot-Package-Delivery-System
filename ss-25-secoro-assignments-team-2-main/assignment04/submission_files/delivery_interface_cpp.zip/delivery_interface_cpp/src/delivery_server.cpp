#include <chrono>
#include <functional>
#include <iostream>
#include <memory>
#include <optional>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <algorithm>

#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "std_msgs/msg/string.hpp"

#include "sensor_msgs/msg/battery_state.hpp"
#include "irobot_create_msgs/msg/dock_status.hpp"
#include "irobot_create_msgs/action/dock.hpp"

#include "geometry_msgs/msg/pose_stamped.hpp"
#include "nav2_msgs/action/navigate_to_pose.hpp"
#include "tf2/LinearMath/Quaternion.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.hpp"

// Generated services
#include "delivery_interface_cpp/srv/delivery_command.hpp"
#include "delivery_interface_cpp/srv/sender_confirm.hpp"
#include "delivery_interface_cpp/srv/receiver_confirm.hpp"

using namespace std::chrono_literals;

using NavigateToPose = nav2_msgs::action::NavigateToPose;
using GoalHandleNavigate = rclcpp_action::ClientGoalHandle<NavigateToPose>;

// ----- Static data (rooms, robots) -----

struct Waypoint { double x; double y; double yaw; };
struct DoorPassage { Waypoint pre; Waypoint post; };


struct RobotState {
  double pct{100.0};          // 0..100
  bool has_battery{false};
  bool is_docked{false};
  bool dock_visible{false};
  // Dock action handle flag to avoid resending
  bool docking_in_progress{false};
};

/* std::unordered_map<std::string, DoorPassage> DOOR_PASSAGES = {
  { "room_251",   {{-4.5,  1.7,  0.0}, {-4.5, 2.3, 0.0} }},
  { "room_252",   {{1.3,  1.7,  0.0},  {1.3, 0.2, 0.0} }},
  {"room_253",    {{ 4.57, 1.7,  0.0}, {4.57, 2.3, 0.0} }},
  {"room_254",    {{ 4.57,-1.7,  0.0}, {4.57, 2.3, 0.0} }},
  {"room_255",    {{ 1.3, -1.7,  0.0}, {1.3, 2.3, 0.0} }},
  {"room_256",    {{-1.3, -1.7,  0.0}, {-1.3, 2.3, 0.0} }},
  {"room_257",    {{-4.5, -1.7,  0.0}, {-4.5, 2.3, 0.0} }},
  {"dock_george", {{-2.25, 2.4,  0.0}, {2.25, 2.4,  0.0 }}},
  {"dock_fred",   {{-2.55, 2.2,  0.0}, {-2.55, 2.2,  0.0} }},

}; */

std::unordered_map<std::string, DoorPassage> DOOR_PASSAGES = {
  { "room_251",   {{3.5,  -3.0,  0.0},     {4.2, -4, 0.0} }},
  { "room_252",   {{-0.7,  -5.6,  0.0},  {0.67, -8.0, 0.0} }},
  {"room_253",    {{ 4.57, 1.7,  0.0}, {4.57, 2.3, 0.0} }},
  {"room_254",    {{ 4.57,-1.7,  0.0}, {4.57, 2.3, 0.0} }},
  {"room_255",    {{ 1.3, -1.7,  0.0}, {1.3, 2.3, 0.0} }},
  {"room_256",    {{1.2, -3.7,  0.0},    {0.3, -1.7, 0.0} }},
  {"room_257",    {{-4.5, -1.7,  0.0}, {-4.5, 2.3, 0.0} }},
  {"dock_george", {{-2.25, 2.4,  0.0}, {2.25, 2.4,  0.0 }}},
  {"dock_fred",   {{3.5,  -3.0,  0.0}, {6.0, -7.0,  0.0} }},

};

/* static const std::unordered_map<std::string, Waypoint> ROOM_LOCATIONS = {
  {"room_251", {-4.5,  1.7,  0.0}},
  {"room_252", { 1.3,  1.7,  0.0}},
  {"room_253", { 4.57, 1.7,  0.0}},
  {"room_254", { 4.57,-1.7,  0.0}},
  {"room_255", { 1.3, -1.7,  0.0}},
  {"room_256", {-1.3, -1.7,  0.0}},
  {"room_257", {-4.5, -1.7,  0.0}},
  {"dock_george",  {-2.25, 2.4,  0.0}},
  {"dock_fred",  {-2.55, 2.2,  0.0}},
}; */


static const std::unordered_map<std::string, Waypoint> ROOM_LOCATIONS = {
  {"room_251", {4.2, -4, 0.0}},
  {"room_252", { 0.67, -8, 0.0}},
  {"room_253", { 4.57, 1.7,  0.0}},
  {"room_254", { 4.57,-1.7,  0.0}},
  {"room_255", { 1.3, -1.7,  0.0}},
  {"room_256", {0.3, -1.7, 0.0}},
  {"room_257", {-4.5, -1.7,  0.0}},
  {"dock_george",  {-2.25, 2.4,  0.0}},
  {"dock_fred",  {6.0, -7.0,  0.0}},
};


static const std::vector<std::string> AVAILABLE_ROBOTS = {"george", "fred"};
static std::unordered_set<std::string> BUSY_ROBOTS;

// ----- DeliveryServer Node -----

class DeliveryServer : public rclcpp::Node {
public:
  DeliveryServer()
  : Node("delivery_server")
  {
    // Service that sender uses to initiate a delivery
    delivery_command_srv_ = this->create_service<delivery_interface_cpp::srv::DeliveryCommand>(
      "/delivery_command",
      std::bind(&DeliveryServer::on_delivery_command, this,
                std::placeholders::_1, std::placeholders::_2));
      
              

    monitor_pub_ = this->create_publisher<std_msgs::msg::String>("/monitor/events", 10);
    for (const auto &ns : AVAILABLE_ROBOTS) {
      battery_pct_[ns] = 100.0;
      is_docked_[ns]   = false;
      dock_visible_[ns]= false;

      auto batt = this->create_subscription<sensor_msgs::msg::BatteryState>(
        "/" + ns + "/battery_state", rclcpp::SensorDataQoS(),
        [this, ns](sensor_msgs::msg::BatteryState::SharedPtr msg) {
          if (msg->percentage >= 0.0) battery_pct_[ns] = msg->percentage * 100.0;
        });
      subs_keepalive_.push_back(batt);

      auto dock = this->create_subscription<irobot_create_msgs::msg::DockStatus>(
        "/" + ns + "/dock_status", rclcpp::SensorDataQoS(),
        [this, ns](irobot_create_msgs::msg::DockStatus::SharedPtr msg) {
          dock_visible_[ns] = msg->dock_visible;
          is_docked_[ns]    = msg->is_docked;
        });
      subs_keepalive_.push_back(dock);
    }

    monitor_available_sub_ = this->create_subscription<std_msgs::msg::String>("/monitor/available", 10,
      [this](std_msgs::msg::String::SharedPtr msg) {
        const std::string name = msg->data;
        // Falls dieser Roboter beim Monitor gesperrt ist → freigeben
        if (monitor_locked_.erase(name) > 0) {
          BUSY_ROBOTS.erase(name);  // wieder verfügbar
          RCLCPP_WARN(this->get_logger(), "[monitor] '%s' marked AVAILABLE by monitor.", name.c_str());
          // wenn es der aktuell zugewiesene Roboter war, Lieferzyklus sauber beenden
          if (assigned_robot_ == name) {
            finish_cycle(); // ruft release_robot_if_any(); Phase -> IDLE; etc.
          }
        }
      }
    );
      

    // Clients we (the server) will call into:
    sender_confirm_client_   = this->create_client<delivery_interface_cpp::srv::SenderConfirm>("/sender/confirm");
    receiver_confirm_client_ = this->create_client<delivery_interface_cpp::srv::ReceiverConfirm>("/receiver/confirm");

    RCLCPP_INFO(this->get_logger(), "DeliveryServer is up. Waiting for /delivery_command requests...");
  }

private:
  // ----- Types / State -----
  enum class Phase {
    IDLE,

    GO_TO_PICKUP,
    WAIT_SENDER_LOAD,
    GO_TO_DELIVERY,
    WAIT_RECEIVER_PICKUP,
    RETURN_TO_SENDER,
    GO_TO_MONITOR,
    GO_TO_DOCK,
    GO_TO_DOOR_PRE,
    GO_TO_DOOR_POST
  };

  enum class TargetKind { PICKUP, DELIVERY };
  TargetKind current_target_{TargetKind::PICKUP};

  static const char* phase_to_string(Phase p) {
    switch (p) {
      case Phase::IDLE: return "IDLE";
      case Phase::GO_TO_PICKUP: return "GO_TO_PICKUP";
      case Phase::GO_TO_DOOR_PRE: return "GO_TO_DOOR_PRE";
      case Phase::GO_TO_DOOR_POST: return "GO_TO_DOOR_POST";
      case Phase::GO_TO_DELIVERY: return "GO_TO_DELIVERY";
      case Phase::RETURN_TO_SENDER: return "RETURN_TO_SENDER";
      case Phase::GO_TO_MONITOR: return "GO_TO_MONITOR";
      case Phase::GO_TO_DOCK: return "GO_TO_DOCK";
      default: return "?";
    }
  }

  // ROS interfaces
  rclcpp::Service<delivery_interface_cpp::srv::DeliveryCommand>::SharedPtr delivery_command_srv_;

  rclcpp::Client<delivery_interface_cpp::srv::SenderConfirm>::SharedPtr sender_confirm_client_;
  rclcpp::Client<delivery_interface_cpp::srv::ReceiverConfirm>::SharedPtr receiver_confirm_client_;

  std::unordered_set<std::string> monitor_locked_; 
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr monitor_available_sub_;

  std::unordered_map<std::string, double> battery_pct_;     
  std::unordered_map<std::string, bool>   is_docked_;       
  std::unordered_map<std::string, bool>   dock_visible_; 
  std::vector<rclcpp::SubscriptionBase::SharedPtr> subs_keepalive_;
  using Dock = irobot_create_msgs::action::Dock;
  std::unordered_map<std::string, rclcpp_action::Client<Dock>::SharedPtr> dock_clients_;
  std::unordered_set<std::string> dock_goal_inflight_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr monitor_pub_;


  rclcpp_action::Client<NavigateToPose>::SharedPtr nav_client_;
  std::string nav_action_name_;  

  // Current delivery context
  Phase phase_ {Phase::IDLE};
  std::string assigned_robot_;
  std::string pickup_room_;
  std::string delivery_room_;
  std::string current_robot_;
  Waypoint current_wp_{};
  int near_goal_counter_ {0};

  // ----- Helpers -----

  std::optional<Waypoint> resolve_room(const std::string &name) {
    auto it = ROOM_LOCATIONS.find(name);
    if (it == ROOM_LOCATIONS.end()) return std::nullopt;
    return it->second;
  }


  void release_robot_if_any() {
    if (!assigned_robot_.empty()) {
      BUSY_ROBOTS.erase(assigned_robot_);
      RCLCPP_INFO(this->get_logger(), "Robot '%s' released.", assigned_robot_.c_str());
      assigned_robot_.clear();
    }
  }

  // Kleine Hilfsfunktion: Text an den Monitor schicken
void monitor_note_(const std::string& text) {
  std_msgs::msg::String m;
  m.data = text;
  monitor_pub_->publish(m);
}

// Dock-Client besorgen (einmal pro Robotername)
rclcpp_action::Client<Dock>::SharedPtr dock_client_(const std::string& ns) {
  auto it = dock_clients_.find(ns);
  if (it != dock_clients_.end()) return it->second;
  auto cli = rclcpp_action::create_client<Dock>(this, "/" + ns + "/dock");
  dock_clients_[ns] = cli;
  return cli;
}

// Zum Dock-Wegpunkt "dock_<name>" navigieren (du hast ROOM_LOCATIONS, resolve_room, send_goal_to_waypoint)
bool go_to_dock_pose_(const std::string& ns) {
  const std::string key = "dock_" + ns;                // z.B. "dock_george"
  auto wp = resolve_room(key);                         // dein vorhandener Resolver
  if (!wp) {
    RCLCPP_ERROR(this->get_logger(), "[%s] Dock-WP '%s' unbekannt.", ns.c_str(), key.c_str());
    monitor_note_("[monitor] " + ns + ": dock waypoint '" + key + "' not found");
    return false;
  }
  send_goal_to_waypoint(*wp);                          // deine vorhandene Nav-Funktion
  RCLCPP_WARN(this->get_logger(), "[%s] Batterie <25%% → zum Dock %s.", ns.c_str(), key.c_str());
  return true;
}

// Nach NAV-Ankunft am Dock-Ziel: Sichtbar? → Dock-Action senden; sonst Monitor-Alarm
void try_dock_after_arrival_(const std::string& ns) {
  if (is_docked_[ns]) return;                          // schon angedockt → fertig
  if (!dock_visible_[ns]) {                            // Dock nicht sichtbar
    monitor_note_("[monitor] " + ns + ": dock not visible/available at dock room");
    RCLCPP_WARN(this->get_logger(), "[%s] Dock nicht sichtbar.", ns.c_str());
    return;
  }
  if (dock_goal_inflight_.count(ns)) return;           // schon gesendet

  auto cli = dock_client_(ns);                         // Dock-Server-Client
  if (!cli->wait_for_action_server(std::chrono::milliseconds(500))) {
    monitor_note_("[monitor] " + ns + ": dock action server not available");
    RCLCPP_WARN(this->get_logger(), "[%s] Dock-Server nicht verfügbar.", ns.c_str());
    return;
  }

  Dock::Goal g;                                        // leeres Dock-Goal
  auto opts = rclcpp_action::Client<Dock>::SendGoalOptions();
  opts.goal_response_callback = [this, ns](auto gh) {
    if (!gh) dock_goal_inflight_.erase(ns);            // abgelehnt → freigeben
  };
  opts.result_callback = [this, ns](auto res) {
    dock_goal_inflight_.erase(ns);                     // nach Ergebnis → freigeben
    if (res.code != rclcpp_action::ResultCode::SUCCEEDED) {
      monitor_note_("[monitor] " + ns + ": dock action failed/aborted");
    }
  };

  dock_goal_inflight_.insert(ns);                      // markieren
  (void)cli->async_send_goal(g, opts);                 // asynchron senden
  RCLCPP_INFO(this->get_logger(), "[%s] Dock-Action gesendet.", ns.c_str());
}

// Paket zum Monitor umleiten (einfacher Fallback-Ort, z.B. "room_251" ODER eigener "monitor"-WP)
void deliver_to_monitor_() {
  // Wähle hier deinen Monitor-Ort: falls du einen Key wie "room_monitor" hast, nimm den.
  const std::string key = "room_251"; // <— ggf. auf "room_monitor" ändern
  auto wp = resolve_room(key);
  if (!wp) {
    RCLCPP_ERROR(this->get_logger(), "[monitor] Monitor-WP '%s' unbekannt.", key.c_str());
    return;
  }
  send_goal_to_waypoint(*wp);                           // gleiche Nav-Funktion wie sonst
  monitor_note_("[monitor] rerouted package to monitor at '" + key + "'");
}


  // Ask the Sender to confirm something (with timeout behavior like Python timed_input)
  bool ask_sender_confirm(const std::string &message, std::chrono::milliseconds timeout = 6000ms) {
    if (!sender_confirm_client_->wait_for_service(1s)) {
      RCLCPP_WARN(this->get_logger(), "Sender confirm service not available.");
      return false;
    }
    auto req = std::make_shared<delivery_interface_cpp::srv::SenderConfirm::Request>();
    req->message = message;

    auto fut = sender_confirm_client_->async_send_request(req);
    if (this->spin_until_future_timeout(fut, timeout)) {
      auto resp = fut.get();
      return resp->confirmed;
    }
    RCLCPP_WARN(this->get_logger(), "Sender confirm timed out.");
    return false;
  }

/*   // Ask the Receiver to provide a delivery room
  std::optional<std::string> ask_receiver_room(const std::string &prompt, std::chrono::milliseconds timeout = 100000ms) {
    if (!receiver_room_client_->wait_for_service(1s)) {
      RCLCPP_WARN(this->get_logger(), "Receiver room service not available.");
      return std::nullopt;
    }
    auto req = std::make_shared<delivery_interface_cpp::srv::ReceiverSelectRoom::Request>();
    req->prompt = prompt;

    auto fut = receiver_room_client_->async_send_request(req);
    if (this->spin_until_future_timeout(fut, timeout)) {
      auto resp = fut.get();
      if (resp->provided && !resp->room.empty()) return resp->room;
      return std::nullopt;
    }
    RCLCPP_WARN(this->get_logger(), "Receiver room selection timed out.");
    return std::nullopt;
  } */

  // Ask the Receiver to confirm pickup
  bool ask_receiver_confirm(const std::string &message, std::chrono::milliseconds timeout = 6000ms) {
    if (!receiver_confirm_client_->wait_for_service(1s)) {
      RCLCPP_WARN(this->get_logger(), "Receiver confirm service not available.");
      return false;
    }
    auto req = std::make_shared<delivery_interface_cpp::srv::ReceiverConfirm::Request>();
    req->message = message;

    auto fut = receiver_confirm_client_->async_send_request(req);
    if (this->spin_until_future_timeout(fut, timeout)) {
      auto resp = fut.get();
      return resp->confirmed;
    }
    RCLCPP_WARN(this->get_logger(), "Receiver confirm timed out.");
    return false;
  }



  // Spin helper with timeout (non-blocking executor-safe)
  template<typename FutureT>
  bool spin_until_future_timeout(FutureT &fut, std::chrono::milliseconds timeout) {
  auto start = std::chrono::steady_clock::now();
  rclcpp::Rate r(50.0);
  while (rclcpp::ok()) {
    if (fut.wait_for(std::chrono::milliseconds(0)) == std::future_status::ready) return true;
    if (std::chrono::steady_clock::now() - start > timeout) return false;
    r.sleep();  
  }
  return false;
}


  // ---- Action: send navigation goal to the assigned robot ----

  void ensure_nav_client_for_robot(const std::string &robot_ns) {
    const auto action_name = "/" + robot_ns + "/navigate_to_pose";
    // Create or recreate the client if we're switching robots or it's not created yet
    if (!nav_client_ || nav_action_name_ != action_name) {
      nav_client_ = rclcpp_action::create_client<NavigateToPose>(this, action_name);
      nav_action_name_ = action_name;  // track current action name
    }
  }

  void send_goal_to_waypoint(const Waypoint &wp) {
    if (assigned_robot_.empty()) {
      RCLCPP_ERROR(this->get_logger(), "No robot assigned to send goal.");
      return;
    }
    ensure_nav_client_for_robot(assigned_robot_);

    if (!nav_client_->wait_for_action_server(5s)) {
      RCLCPP_ERROR(this->get_logger(),
                   "NavigateToPose action server '%s' not available.",
                   nav_action_name_.c_str());
      // Decide how to failover: go to monitor
      transition_to_monitor();
      return;
    }

    NavigateToPose::Goal goal_msg;
    geometry_msgs::msg::PoseStamped pose;
    pose.header.frame_id = "map";
    pose.header.stamp = this->now();
    pose.pose.position.x = wp.x;
    pose.pose.position.y = wp.y;
    tf2::Quaternion q;
    q.setRPY(0.0, 0.0, wp.yaw);
    pose.pose.orientation = tf2::toMsg(q);
    goal_msg.pose = pose;

    near_goal_counter_ = 0;

    auto opts = rclcpp_action::Client<NavigateToPose>::SendGoalOptions();

    opts.feedback_callback =
      [this](GoalHandleNavigate::SharedPtr /*unused*/,
             const std::shared_ptr<const NavigateToPose::Feedback> feedback)
      {
        const double d = feedback->distance_remaining;
        
        if (d < 0.1) {
          near_goal_counter_++;
        } else {
          near_goal_counter_ = 0;
        }
        if (near_goal_counter_ > 5) {
          RCLCPP_WARN(this->get_logger(),
            "Stuck near goal! Possibly blocked (door closed). Please check the door.");
        }
      };

    opts.goal_response_callback =
      [this](std::shared_ptr<GoalHandleNavigate> gh) {
        if (!gh) {
          RCLCPP_ERROR(this->get_logger(), "Goal rejected by server.");
        } else {
          RCLCPP_INFO(this->get_logger(), "Goal accepted.");
        }
      };

    opts.result_callback =
      [this](const GoalHandleNavigate::WrappedResult &result) {
        using RC = rclcpp_action::ResultCode;

        if (result.code == RC::SUCCEEDED) {
          RCLCPP_INFO(this->get_logger(), "Robot arrived at destination.");
          if (phase_ == Phase::GO_TO_DOCK && !assigned_robot_.empty()) {
            try_dock_after_arrival_(assigned_robot_);
          }
          // Success path: advance the finite-state machine
          this->advance_state_after_nav();
          return;
        }

        if (result.code == RC::ABORTED) {
          RCLCPP_WARN(this->get_logger(), "Navigation aborted in phase %d! Possibly blocked.",
                      static_cast<int>(phase_));

          // --- door-specific handling (enable AFTER we add the new enum) ---
          // if (phase_ == Phase::GO_TO_DOOR_POST) {
          //   monitor_note_("[monitor] Door closed for " + delivery_room_);
          //   // choose your policy; example: park at monitor
          //   phase_ = Phase::GO_TO_MONITOR;
          //   transition_to_monitor();
          //   return;  // don't call advance_state_after_nav() here
          // }

          // Generic fallback for now: go to dock
          if (!assigned_robot_.empty()) {
            phase_ = Phase::GO_TO_DOCK;
            go_to_dock_pose_(assigned_robot_);
            return;  // we launched a new goal; don't advance FSM now
          }

          // If no robot assigned, just log and stop
          RCLCPP_ERROR(this->get_logger(), "No robot assigned; cannot fallback after ABORTED.");
          return;
        }

        if (result.code == RC::CANCELED) {
          RCLCPP_WARN(this->get_logger(), "Navigation canceled in phase %d.", static_cast<int>(phase_));
          // Treat like aborted → go to dock (or your policy)
          if (!assigned_robot_.empty()) {
            phase_ = Phase::GO_TO_DOCK;
            go_to_dock_pose_(assigned_robot_);
          } else {
            RCLCPP_ERROR(this->get_logger(), "No robot assigned; cannot fallback after CANCELED.");
          }
          return;
        }

        // Unknown result: be safe, go to dock if possible
        RCLCPP_ERROR(this->get_logger(), "Navigation ended with unknown status code %d.",
                    static_cast<int>(result.code));
        if (!assigned_robot_.empty()) {
          phase_ = Phase::GO_TO_DOCK;
          go_to_dock_pose_(assigned_robot_);
        }
        // no advance_state_after_nav() here either
      };


    nav_client_->async_send_goal(goal_msg, opts);
  }

  // ---- State machine transitions ----

  void advance_state_after_nav() {
    switch (phase_) {

      // === Robot has just reached the PICKUP ===
      case Phase::GO_TO_PICKUP: {
        const bool loaded = ask_sender_confirm("Sender: Please confirm package loaded [y]: ");
        if (!loaded) {
          RCLCPP_WARN(this->get_logger(),
                      "No confirmation from sender. Returning to dock.");
          phase_ = Phase::GO_TO_DOCK;
          go_to_dock_pose_(assigned_robot_);
          break;
        }

        // If this delivery room uses a door passage, go pre-door first
        auto door_it = DOOR_PASSAGES.find(delivery_room_);
        if (door_it != DOOR_PASSAGES.end()) {
          const auto &d = door_it->second;
          current_wp_ = d.pre;
          phase_ = Phase::GO_TO_DOOR_PRE;
          send_goal_to_waypoint(current_wp_);
          RCLCPP_INFO(this->get_logger(),
                      "Sender confirmed. Heading to PRE-DOOR waypoint for '%s'.",
                      delivery_room_.c_str());
        } else {
          // No door handling: go straight to delivery room
          auto optional_wp = resolve_room(delivery_room_);
          if (optional_wp) {
            current_wp_ = *optional_wp;
            phase_ = Phase::GO_TO_DELIVERY;
            send_goal_to_waypoint(current_wp_);
            RCLCPP_INFO(this->get_logger(),
                        "Sender confirmed. Heading directly to delivery '%s'.",
                        delivery_room_.c_str());
          } else {
            // Defensive: should not happen if client validated rooms
            RCLCPP_ERROR(this->get_logger(),
                        "Delivery room '%s' could not be resolved. Returning to dock.",
                        delivery_room_.c_str());
            phase_ = Phase::GO_TO_DOCK;
            go_to_dock_pose_(assigned_robot_);
          }
        }
        break;
      }

    case Phase::GO_TO_DOOR_PRE: {
      // Robot reached the waypoint before the door
      RCLCPP_INFO(this->get_logger(), "Reached pre-door waypoint for room %s.", delivery_room_.c_str());

      // Next: try to go through the door
      auto optional_wp = resolve_room(delivery_room_);
      if (optional_wp) {
        phase_ = Phase::GO_TO_DOOR_POST;
        send_goal_to_waypoint(*optional_wp);
      } else {
        RCLCPP_WARN(this->get_logger(),
                    "Could not resolve delivery room '%s'. Going to dock.",
                    delivery_room_.c_str());
        phase_ = Phase::GO_TO_DOCK;
        go_to_dock_pose_(assigned_robot_);
      }
      break;
    }

    case Phase::GO_TO_DOOR_POST: {
      // If we arrived here, the door was open and we got through
      RCLCPP_INFO(this->get_logger(), "Passed door and arrived at delivery room %s.", delivery_room_.c_str());

      // From here continue with delivery confirmation
      bool picked = ask_receiver_confirm("Receiver: Confirm package picked up [y]: ");
      if (picked) {
        RCLCPP_INFO(this->get_logger(), "Package picked up. Returning to dock.");
        phase_ = Phase::GO_TO_DOCK;
        go_to_dock_pose_(assigned_robot_);
      } else {
        RCLCPP_WARN(this->get_logger(), "Receiver did not confirm. Returning to sender.");
        phase_ = Phase::RETURN_TO_SENDER;
        auto optional_wp = resolve_room(pickup_room_);
        if (optional_wp) {
          send_goal_to_waypoint(*optional_wp);
        } else {
          RCLCPP_ERROR(this->get_logger(), "Pickup room resolution failed. Going to dock.");
          phase_ = Phase::GO_TO_DOCK;
          go_to_dock_pose_(assigned_robot_);
        }
      }
      break;
    }

      // === Robot has just reached the DELIVERY ===
      case Phase::GO_TO_DELIVERY: {
        const bool picked = ask_receiver_confirm("Receiver: Confirm package picked up [y]: ");
        if (picked) {
          RCLCPP_INFO(this->get_logger(), "Returning to dock station.");
          phase_ = Phase::GO_TO_DOCK;
          go_to_dock_pose_(assigned_robot_);
        } else {
          RCLCPP_WARN(this->get_logger(),
                      "No response from receiver. Returning package to sender.");
          phase_ = Phase::RETURN_TO_SENDER;
          auto optional_wp = resolve_room(pickup_room_);
          if (optional_wp) {
            current_wp_ = *optional_wp;
            send_goal_to_waypoint(current_wp_);
          } else {
            // Defensive fallback
            RCLCPP_ERROR(this->get_logger(),
                        "Pickup room '%s' could not be resolved. Going to dock.",
                        pickup_room_.c_str());
            phase_ = Phase::GO_TO_DOCK;
            go_to_dock_pose_(assigned_robot_);
          }
        }
        break;
      }

      // === Robot has just reached the SENDER again to return the package ===
      case Phase::RETURN_TO_SENDER: {
        const bool returned = ask_sender_confirm("Sender: Confirm package was returned [y]: ");
        if (returned) {
          RCLCPP_INFO(this->get_logger(), "Package returned to sender successfully.");
          finish_cycle();
        } else {
          RCLCPP_WARN(this->get_logger(),
                      "Sender not responding. Sending robot to monitor.");
          transition_to_monitor();
        }
        break;
      }

      // === Robot has parked at monitor ===
      case Phase::GO_TO_MONITOR: {
        RCLCPP_INFO(this->get_logger(),
          "Robot is parked at monitor; waiting for monitor to mark it available via /monitor/available.");
        break; // stays held until monitor frees it
      }

      // === Robot has docked ===
      case Phase::GO_TO_DOCK: {
        RCLCPP_INFO(this->get_logger(),
                    "Robot is docked or sent to monitor. Available for next task.");
        finish_cycle();
        break;
      }

      default:
        break;
    }
  }


  void transition_to_monitor() {
    if (!assigned_robot_.empty()) {
      monitor_locked_.insert(assigned_robot_);
      BUSY_ROBOTS.insert(assigned_robot_);  // sicherstellen, dass er als "busy" bleibt
    }

    phase_ = Phase::GO_TO_MONITOR;

    auto wp = resolve_room("room_251"); // oder eigener Monitor-Wegpunkt
    if (wp) {
      send_goal_to_waypoint(*wp);
    } else {
      RCLCPP_ERROR(this->get_logger(), "Monitor room not defined; holding robot locked until manual release.");
      // WICHTIG: NICHT finish_cycle() rufen -> blockiert, bis Monitor freigibt
    }
  }

  void start_pickup_navigation() {
    auto wp = resolve_room(pickup_room_);
    if (!wp) {
      RCLCPP_ERROR(this->get_logger(), "Invalid pickup room '%s'.", pickup_room_.c_str());
      finish_cycle();
      return;
    }
    current_wp_ = *wp;
    phase_ = Phase::GO_TO_PICKUP;
    send_goal_to_waypoint(current_wp_);
  }

  void finish_cycle() {
    release_robot_if_any();
    phase_ = Phase::IDLE;
    pickup_room_.clear();
    delivery_room_.clear();
    monitor_note_("[delivery] Cycle complete");
    RCLCPP_INFO(this->get_logger(), "Cycle complete. Ready for next /delivery_command.");
  }

  // ----- /delivery_command callback -----

  void on_delivery_command(
    const std::shared_ptr<delivery_interface_cpp::srv::DeliveryCommand::Request> req,
    std::shared_ptr<delivery_interface_cpp::srv::DeliveryCommand::Response> resp)
  {
    if (phase_ != Phase::IDLE) {
      RCLCPP_WARN(this->get_logger(), "Delivery already in progress. Rejecting new request.");
      resp->accepted = false;
      resp->assigned_robot = "";
      return;
    }

    // Validate pickup room
    pickup_room_ = req->pickup_room;
    delivery_room_ = req->delivery_room;
    if (!resolve_room(pickup_room_)) {
      RCLCPP_ERROR(this->get_logger(), "Unknown pickup room '%s'.", pickup_room_.c_str());
      resp->accepted = false;
      resp->assigned_robot = "";
      return;
    }

    // Choose a robot
    // === ROBOTER AUSWAHL (mit Batterieprüfung & Dock-Routing) ===
// Diese Lambda filtert freie Roboter, prüft Batterie ≥25%,
// schickt zu Dock wenn <25% (aber wählt ihn jetzt NICHT aus).
    auto pick_robot = [&]() -> std::optional<std::string> {
      double best_pct = -1.0;                           // merkt besten Prozentwert
      std::optional<std::string> best;                  // merkt besten Roboternamen

      for (const auto &r : AVAILABLE_ROBOTS) {          // über alle bekannten Roboter
        if (BUSY_ROBOTS.count(r)) continue;             // überspringe beschäftigte

        const double pct = battery_pct_.count(r) ?      // Batterie lesen (Default 100, falls noch nichts)
                            battery_pct_[r] : 100.0;

        if (pct < 25.0) {                               // zu wenig Batterie?
          if (!is_docked_[r]) {                         // noch nicht angedockt?
            if (!go_to_dock_pose_(r)) {                 // fahre zum Dock-WP "dock_<name>"
              // Ziel nicht erreichbar → Monitor informieren + Paket zum Monitor umleiten
              monitor_note_("[monitor] " + r + ": dock destination not reachable");
              deliver_to_monitor_();
            }
            // Docken selbst erst NACH Ankunft → try_dock_after_arrival_(r) im Nav-"Ankunft"-Pfad
          }
          continue;                                     // überspringen, nicht als Lieferroboter wählen
        }

        if (pct > best_pct) { best_pct = pct; best = r; } // besten Kandidaten merken
      }

      if (best) BUSY_ROBOTS.insert(*best);              // als beschäftigt markieren (dein bestehendes Konzept)
      return best;                                      // Kandidat (oder leer)
    }();

    if (!pick_robot) {
      // Kein Roboter mit ≥25% → Auftrag ablehnen ODER (optional) direkt zum Monitor liefern
      RCLCPP_ERROR(this->get_logger(), "No available robots.");
      // Optional: Paket direkt zum Monitor
      // deliver_to_monitor_();
      resp->accepted = false;
      resp->assigned_robot = "";
      return;
    }

    // Kandidaten übernehmen (Rest deiner Logik bleibt unverändert)
    assigned_robot_ = *pick_robot;                       // welcher Roboter liefert
    resp->accepted = true;                               // Auftrag angenommen
    resp->assigned_robot = assigned_robot_;              // Rückgabe an Client

    RCLCPP_INFO(this->get_logger(), "Assigned '%s' for pickup at '%s' (battery %.1f%%).",
                assigned_robot_.c_str(), pickup_room_.c_str(),
                battery_pct_.count(assigned_robot_) ? battery_pct_[assigned_robot_] : -1.0);


    // Kick off navigation to pickup
    start_pickup_navigation();
  }
};

// ----- main -----
int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  auto node = std::make_shared<DeliveryServer>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
